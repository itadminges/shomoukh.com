<?php
namespace VamtamElementor\ElementorHooks;

// Elementor actions.
add_action( \Vamtam_Elementor_Utils::get_widgets_registration_hook(),      __NAMESPACE__ . '\register_widgets', 999999 );
add_action( 'elementor/editor/before_enqueue_scripts',   __NAMESPACE__ . '\enqueue_editor_scripts' );
add_action( 'elementor/frontend/before_enqueue_scripts', __NAMESPACE__ . '\frontend_before_enqueue_scripts' );
add_action( 'elementor/init', __NAMESPACE__ . '\elementor_init' );

// add_action( 'elementor/preview/enqueue_styles',          'Vamtam_Elementor_Widgets_Handler::enqueue_theme_editor_styles' );

// Elementor filters
add_filter( 'elementor/controls/animations/additional_animations', __NAMESPACE__ . '\vamtam_elementor_additional_animations' );
add_filter( 'elementor/controls/hover_animations/additional_animations', __NAMESPACE__ . '\vamtam_elementor_additional_hover_animations' );
add_filter( 'elementor/image_size/get_attachment_image_html', __NAMESPACE__ . '\vamtam_add_no_lazy_class_to_img_element', 11, 4 );

function elementor_init() {
	// Theme-dependant.
	set_experiments_default_state();

	// One-time: enable Atomic Elements on installs initialized before it was whitelisted.
	migrate_enable_atomic_elements();

	// One-time: same for Size Variables.
	migrate_enable_pro_variables();

	// One-time: same for the v4 design system (Variables + Classes).
	migrate_enable_v4_design_system();

	// One-time: same for Interactions (core + Pro).
	migrate_enable_interactions();

	// One-time: same for Atomic Form.
	migrate_enable_atomic_form();

	set_performance_options();
}

/*
	Sets all Stable features to their default value & disables all Ongoing experiments by default.
	Happens only once (based on option).
*/
function set_experiments_default_state() {
	if ( get_option( 'vamtam-set-experiments-default-state', false ) ) {
		return;
	}

	$exps     = \Elementor\Plugin::$instance->experiments;
	$features = $exps->get_features();

	foreach ( $features as $fname => $fdata ) {
		if ( $fdata['release_status'] === 'stable' ) {
			// Stable experiments.

			// Features to force-disable.
			$fdisable = [
				'additional_custom_breakpoints',
				'e_font_icon_svg',
			];

			if ( in_array( $fname, $fdisable ) ) {
				// Force-disable.
				update_option( 'elementor_experiment-' . $fname, $exps::STATE_INACTIVE );
				continue;
			}

			// Force default state.
			update_option( 'elementor_experiment-' . $fname, $exps::STATE_DEFAULT );

		} else {
			// Ongoing experiments.

			// Features needed for theme - keep enabled.
			$fenable = [
				'e_atomic_elements',
				'e_pro_variables',
				'e_variables',
				'e_classes',
				'e_interactions',
				'e_pro_interactions',
				'e_pro_atomic_form',
			];

			if ( in_array( $fname, $fenable ) ) {
				// Force-enable.
				update_option( 'elementor_experiment-' . $fname, $exps::STATE_ACTIVE );
				$exps->set_feature_default_state( $fname, $exps::STATE_ACTIVE );
				continue;
			}

			// Force-disable.
			update_option( 'elementor_experiment-' . $fname, $exps::STATE_INACTIVE );

			// Set it's current default state to inactive
			$exps->set_feature_default_state( $fname, $exps::STATE_INACTIVE );
		}
	}

	update_option( 'vamtam-set-experiments-default-state', true );
}

/*
	One-time migration: force-enable the Atomic Elements experiment on existing installs whose
	experiments state was initialized before this feature was whitelisted. Guarded by its own
	option, independent of set_experiments_default_state()'s master guard, so it runs once even
	when that guard is already set (e.g. after a plugin update from a pre-atomic version).
*/
function migrate_enable_atomic_elements() {
	if ( get_option( 'vamtam-migrated-atomic-elements', false ) ) {
		return;
	}

	$exps = \Elementor\Plugin::$instance->experiments;
	update_option( 'elementor_experiment-e_atomic_elements', $exps::STATE_ACTIVE );
	$exps->set_feature_default_state( 'e_atomic_elements', $exps::STATE_ACTIVE );

	update_option( 'vamtam-migrated-atomic-elements', true );
}

/*
	One-time migration: force-enable the Size Variables experiment (e_pro_variables) on existing
	installs, whose experiments state was initialized while it was still being force-disabled as
	an alpha feature. Same guard-per-migration approach as migrate_enable_atomic_elements().

	Without it the editor never loads Elementor Pro's editor-variables-extended package, so the
	Variables panel lists the colors and fonts but silently drops every size variable, while the
	REST API keeps storing and validating them - adding a size then fails as a duplicate of a
	record the panel is hiding. The experiment is registered with 'hidden' => true, so it cannot
	be switched back on from Elementor > Features either.
*/
function migrate_enable_pro_variables() {
	if ( get_option( 'vamtam-migrated-pro-variables', false ) ) {
		return;
	}

	$exps = \Elementor\Plugin::$instance->experiments;
	update_option( 'elementor_experiment-e_pro_variables', $exps::STATE_ACTIVE );
	$exps->set_feature_default_state( 'e_pro_variables', $exps::STATE_ACTIVE );

	update_option( 'vamtam-migrated-pro-variables', true );
}

/*
	One-time migration: force-enable the two experiments the v4 design system is built on -
	Variables (e_variables) and Classes (e_classes). Both are alpha, so existing installs had
	them force-disabled by set_experiments_default_state() along with everything else ongoing,
	and its master guard means simply whitelisting them now would never reach those sites.

	These themes already force-enable e_opt_in_v4 and e_opt_in_v4_page, and v4 opted in with the
	design system switched off is the same broken half-state that hid the size variables.

	Unlike e_pro_variables these two are visible in Elementor > Features, so this deliberately
	runs once and then leaves them alone - turning either back off by hand has to stick.
*/
function migrate_enable_v4_design_system() {
	if ( get_option( 'vamtam-migrated-v4-design-system', false ) ) {
		return;
	}

	$exps = \Elementor\Plugin::$instance->experiments;

	foreach ( [ 'e_variables', 'e_classes' ] as $fname ) {
		update_option( 'elementor_experiment-' . $fname, $exps::STATE_ACTIVE );
		$exps->set_feature_default_state( $fname, $exps::STATE_ACTIVE );
	}

	update_option( 'vamtam-migrated-v4-design-system', true );
}

/*
	One-time migration: force-enable Interactions - both the core experiment (e_interactions) and
	the Pro one that builds on it (e_pro_interactions). Same guard-per-migration approach as the
	migrations above.

	Both are registered as dev features with 'hidden' => true, so set_experiments_default_state()
	force-disabled them along with everything else ongoing, and there is no switch in
	Elementor > Features to turn them back on by hand.

	Both also require e_atomic_elements, which these themes already force-enable.
*/
function migrate_enable_interactions() {
	if ( get_option( 'vamtam-migrated-interactions', false ) ) {
		return;
	}

	$exps = \Elementor\Plugin::$instance->experiments;

	foreach ( [ 'e_interactions', 'e_pro_interactions' ] as $fname ) {
		update_option( 'elementor_experiment-' . $fname, $exps::STATE_ACTIVE );
		$exps->set_feature_default_state( $fname, $exps::STATE_ACTIVE );
	}

	update_option( 'vamtam-migrated-interactions', true );
}

/*
	One-time migration: force-enable the Atomic Form experiment (e_pro_atomic_form). Same
	guard-per-migration approach as the migrations above.

	Registered by Elementor Pro as a dev feature with 'hidden' => true, so
	set_experiments_default_state() force-disabled it along with everything else ongoing, and
	there is no switch in Elementor > Features to turn it back on by hand.

	There is no core counterpart - Elementor core checks e_pro_atomic_form directly when
	registering the atomic form element. Its only dependency is e_atomic_elements, which these
	themes already force-enable.
*/
function migrate_enable_atomic_form() {
	if ( get_option( 'vamtam-migrated-atomic-form', false ) ) {
		return;
	}

	$exps = \Elementor\Plugin::$instance->experiments;

	update_option( 'elementor_experiment-e_pro_atomic_form', $exps::STATE_ACTIVE );
	$exps->set_feature_default_state( 'e_pro_atomic_form', $exps::STATE_ACTIVE );

	update_option( 'vamtam-migrated-atomic-form', true );
}

function __return_inactive_experiment( $state ) {
	return \Elementor\Plugin::$instance->experiments::STATE_INACTIVE;
}

function set_performance_options() {
	$force_disable_elements_cache = apply_filters( 'vamtam_force_disable_elementor_elements_cache', true );

	if ( $force_disable_elements_cache ) {
		add_filter( 'pre_option_elementor_element_cache_ttl', function( $ttl ) {
			return 'disable';
		}, 999 );
	}

	$fdisable = [];
	$selectors = [];

	if ( $force_disable_elements_cache ) {
		$fdisable[] = 'e_element_cache';
		$selectors[] = '.elementor_experiment-e_element_cache';
	}

	// temporarily allow this only on internal sites
	if ( ! function_exists( 'vamtam_internal_adminbar' ) ) {
		$fdisable[] = 'e_optimized_markup';
		$selectors[] = '.elementor_experiment-e_optimized_markup';
	}

	// Features to force-disable.
	foreach ( $fdisable as $fname ) {
		update_option( 'elementor_experiment-' . $fname, \Elementor\Plugin::$instance->experiments::STATE_INACTIVE );
		add_filter( 'pre_option_elementor_experiment-' . $fname, __NAMESPACE__ . '\__return_inactive_experiment' );
	}

	if ( ! empty( $selectors ) ) {
		add_action( 'admin_enqueue_scripts', function() use ( $selectors ) {
			$screen = get_current_screen();
			if ( $screen && $screen->id === 'elementor_page_elementor-settings' ) {
				$css = implode( ', ', $selectors ) . ' {
						display: none;
					}
				';
				wp_add_inline_style( 'elementor-admin', $css );
			}
		} );
	}
}

function vamtam_elementor_additional_animations( $additional_anims ) {
	if ( current_theme_supports( 'vamtam-elementor-widgets', 'widgets--horizontal-grow-anims' ) ) {
		if ( ! isset( $additional_anims[ 'Vamtam' ] ) ) {
			$additional_anims[ 'Vamtam' ] = [];
		}
		$additional_anims[ 'Vamtam' ] = $additional_anims[ 'Vamtam' ] + [
			'growFromLeft' => __( 'Grow From Left', 'vamtam-elementor-integration' ),
			'growFromRight' => __( 'Grow From Right', 'vamtam-elementor-integration' ),
		];
	}
	if ( current_theme_supports( 'vamtam-elementor-widgets', 'widgets--horizontal-grow-scroll-based-anims' ) ) {
		if ( ! isset( $additional_anims[ 'Vamtam' ] ) ) {
			$additional_anims[ 'Vamtam' ] = [];
		}
		$additional_anims[ 'Vamtam' ] = $additional_anims[ 'Vamtam' ] + [
			'growFromLeftScroll' => __( 'Grow From Left (Scroll Based)', 'vamtam-elementor-integration' ),
			'growFromRightScroll' => __( 'Grow From Right (Scroll Based)', 'vamtam-elementor-integration' ),
		];
	}
	if ( current_theme_supports( 'vamtam-elementor-widgets', 'image--grow-with-scale-anims' ) ) {
		if ( ! isset( $additional_anims[ 'Vamtam' ] ) ) {
			$additional_anims[ 'Vamtam' ] = [];
		}
		$additional_anims[ 'Vamtam' ] = $additional_anims[ 'Vamtam' ] + [
			'imageGrowWithScaleLeft' => __( 'Image - Grow With Scale (Left)', 'vamtam-elementor-integration' ),
			'imageGrowWithScaleRight' => __( 'Image - Grow With Scale (Right)', 'vamtam-elementor-integration' ),
			'imageGrowWithScaleTop' => __( 'Image - Grow With Scale (Top)', 'vamtam-elementor-integration' ),
			'imageGrowWithScaleBottom' => __( 'Image - Grow With Scale (Bottom)', 'vamtam-elementor-integration' ),
		];
	}
	return $additional_anims;
}

function vamtam_elementor_additional_hover_animations( $additional_hover_anims ) {
	if ( current_theme_supports( 'vamtam-elementor-widgets', 'form--prefix-grow-hover-anims' ) ) {
		$additional_hover_anims = $additional_hover_anims + [
			'prefix-grow' => __( 'Prefix Grow', 'vamtam-elementor-integration' ),
			'prefix-grow-alt' => __( 'Prefix Grow Alt', 'vamtam-elementor-integration' ),
		];
	}
	return $additional_hover_anims;
}

function register_widgets() {
	\Vamtam_Elementor_Widgets_Handler::instance();
}

function frontend_before_enqueue_scripts() {
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	// Enqueue JS for Elementor (frontend).
	wp_enqueue_script(
		'vamtam-elementor-frontend',
		VAMTAM_ELEMENTOR_INT_URL . 'assets/js/vamtam-elementor-frontend' . $suffix . '.js',
		[
			'elementor-frontend', // dependency
		],
		\VamtamElementorIntregration::PLUGIN_VERSION,
		true //in footer
	);
}

function enqueue_editor_scripts() {
	// Enqueue JS for Elementor editor.
	wp_enqueue_script( 'vamtam-elementor', VAMTAM_ELEMENTOR_INT_URL . 'assets/js/vamtam-elementor.js', [], \VamtamElementorIntregration::PLUGIN_VERSION, true );
}

/*
	Add the no-lazy class to the <img> element, if the root widget element has it.
	We need this cause Elementor adds the Custom CSS classes to the root widget element
	but caching plugins need it directly on the <img> element in order not to lazy-load it.
*/
function vamtam_add_no_lazy_class_to_img_element( $html, $settings, $image_size_key, $image_key ) {
	if ( ! isset( $settings[ '_css_classes' ] ) || empty( $settings[ '_css_classes' ] ) || strpos( $settings[ '_css_classes' ], 'no-lazy' ) === false ) {
		return $html;
	}

	$attrClass = strpos( $html, "class=" );
	if ( $attrClass ) {
		$html = preg_replace( '/class="(.*)"/', 'class="' . 'no-lazy' . ' \1"', $html );
	} else {
		$html = preg_replace( '/src="(.*)"/', 'class="' . 'no-lazy' . '" src="\1"', $html );
	}

	return $html;
}
